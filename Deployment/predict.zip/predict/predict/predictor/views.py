from django.shortcuts import render
import numpy as np
import pandas as pd
import pickle
import os
from django.conf import settings
# Create your views here.


def predict_function(date,country,active_cases,dynamic_input):
	if country == "Russia":
		file_path_model = os.path.join(settings.STATIC_ROOT,"predictor/pickle/russia_xgboost.sav")
		file_path_scaler = os.path.join(settings.STATIC_ROOT,"predictor/pickle/scaler_russia.sav")
		model_russia = pickle.load(open(file_path_model,'rb'))
		scaler_russia = pickle.load(open(file_path_scaler,'rb'))
		data=pd.DataFrame(data=[[date,active_cases,dynamic_input]],columns=["date","active_cases","dynamic_input"])
		prediction = model_russia.predict(scaler_russia.transform(data))
		return prediction

	elif country == "Brazil":
		file_path_model = os.path.join(settings.STATIC_ROOT,"predictor/pickle/brazil_xgboost.sav")
		file_path_scaler = os.path.join(settings.STATIC_ROOT,"predictor/pickle/scaler_brazil.sav")
		model_brazil = pickle.load(open(file_path_model,'rb'))
		scaler_brazil = pickle.load(open(file_path_scaler,'rb'))
		data=pd.DataFrame(data=[[date,active_cases,dynamic_input]],columns=["date","active_cases","dynamic_input"])
		prediction= model_brazil.predict(scaler_brazil.transform(data))
		return prediction

	elif country == "Australia":
		file_path_model = os.path.join(settings.STATIC_ROOT,"predictor/pickle/australia_svr.sav")
		file_path_scaler = os.path.join(settings.STATIC_ROOT,"predictor/pickle/scaler_australia.sav")
		model_australia = pickle.load(open(file_path_model,'rb'))
		scaler_australia = pickle.load(open(file_path_scaler,'rb'))
		data=pd.DataFrame(data=[[date,active_cases,dynamic_input]],columns=["date","active_cases","dynamic_input"])
		prediction = model_australia.predict(scaler_australia.transform(data))
		return prediction

	elif country == "Nigeria":
		file_path_model = os.path.join(settings.STATIC_ROOT,"predictor/pickle/nigeria_gb.sav")
		file_path_scaler = os.path.join(settings.STATIC_ROOT,"predictor/pickle/scaler_nigeria.sav")
		model_nigeria = pickle.load(open(file_path_model,'rb'))
		scaler_nigeria = pickle.load(open(file_path_scaler,'rb'))
		data=pd.DataFrame(data=[[date,active_cases,dynamic_input]],columns=["date","active_cases","dynamic_input"])
		prediction = model_nigeria.predict(scaler_nigeria.transform(data))
		return prediction

	elif country == "USA":
		file_path_model = os.path.join(settings.STATIC_ROOT,"predictor/pickle/usa_xgboost.sav")
		file_path_scaler = os.path.join(settings.STATIC_ROOT,"predictor/pickle/scaler_usa.sav")
		model_usa = pickle.load(open(file_path_model,'rb'))
		scaler_usa = pickle.load(open(file_path_scaler,'rb'))
		data=pd.DataFrame(data=[[date,active_cases,dynamic_input]],columns=["date","active_cases","dynamic_input"])
		prediction = model_usa.predict(scaler_usa.transform(data))
		return prediction

def predict_death_specific(request):
	form={}
	
	if request.GET.get("country",0) != 0:
		raw_date = request.GET["date"]
		date = pd.to_datetime((request.GET["date"])).strftime('%y%m%d')
		date=pd.to_numeric(date)
		active_cases = int(request.GET["active_cases"])
		dynamic_input = int(request.GET["dynamic_input"])
		country=request.GET["country"]
		prediction = np.abs(predict_function(date,country,active_cases,dynamic_input))
		form["date"] = raw_date
		form["country"] = country
		form["active_cases"] = str(active_cases)
		form["dynamic_input"] = str(dynamic_input)
		form["prediction"] = int(np.round(prediction))

	return render(request, 'predictor/home.html',{"form":form})


def predict_death_global(request):
	form={}
	if request.GET.get("date",0) != 0:
		raw_date = request.GET["date"]
		date = pd.to_datetime(request.GET["date"])
		file_path_model = os.path.join(settings.STATIC_ROOT,"predictor/pickle/global_model_ts.sav")
		model_global = pickle.load(open(file_path_model,'rb'))
		pred_date = pd.DataFrame({'ds':[date]})
		prediction = int(round(model_global.predict(pred_date)["yhat"][0]))
		form["date"] = raw_date
		form["prediction"] = prediction

	return render(request, 'predictor/global.html',{"form":form})