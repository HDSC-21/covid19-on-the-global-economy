from django.shortcuts import render
import numpy as np
import pandas as pd
import pickle
import os
from django.conf import settings
# Create your views here.



def predict_death_global(request):
	form={}
	if request.GET.get("date",0) != 0:
		raw_date = request.GET["date"]
		date = pd.to_datetime(request.GET["date"])
		file_path_model = os.path.join(settings.STATIC_ROOT,"predictor/pickle/global_model_ts.sav")
		model_global = pickle.load(open(file_path_model,'rb'))
		pred_date = pd.DataFrame({'ds':[date]})
		prediction = int(round(model_global.predict(pred_date)["yhat"][0]))
		form["date"] = raw_date
		form["prediction"] = prediction

	return render(request, 'predictor/global.html',{"form":form})